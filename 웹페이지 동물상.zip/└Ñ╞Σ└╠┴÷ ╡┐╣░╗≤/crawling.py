from gids import builder

config = {
    'driver_path': './chromedriver',
    'headless': True,
    'window-size': '720x480',
    'disable_gpu': False
}

first_item = {
    'keyword': '방탄소년단 정국',
    'limit': 30, # The number of images
    'download_context': './face',
    'path': '토끼' # save in ./data/animal/img_01...10
}

second_item = {
    'keyword': '아이콘 바비',
    'limit': 30, # The number of images
    'download_context': './face',
    'path': '토끼' # save in ./data/plant/img_01...10
}

third_item = {
    'keyword': '워너원 박지훈',
    'limit': 30, # The number of images
    'download_context': './face',
    'path': '토끼' # save in ./data/plant/img_01...10
}

forth_item = {
    'keyword': '엑소 수호',
    'limit': 30, # The number of images
    'download_context': './face',
    'path': '토끼' # save in ./data/plant/img_01...10
}

items = [first_item, second_item, third_item, forth_item]

downloader = builder.build(config)

downloader.download(items)
